---
id: 2
title: Home
date: 2016-09-30T16:02:13+00:00
author: jiming5_wp
layout: page
guid: http://jimingshi.us/?page_id=2
---
<p style="text-align: left;">
  <span style="font-size: 14pt;">I am currently an Associated</span><span style="font-size: 14pt;"> Research Scholar at </span><span style="font-size: 14pt;"><a href="http://www.astro.princeton.edu/">Department of Astrophysical Sciences</a></span><span style="font-size: 14pt;"><a> &<br /> </a><a href="http://www.princeton.edu/plasmacenter/">Max-Planck-Princeton Center for Plasma Physics</a></span><span style="font-size: 14pt;"> of <a href="http://www.princeton.edu">Princeton University</a>. </span>
</p>

<p style="text-align: left;">
  <span style="font-size: 14pt;"> </span>
</p>