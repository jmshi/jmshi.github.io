---
id: 94
title: CV
date: 2016-10-03T04:00:10+00:00
author: jiming5_wp
layout: page
guid: http://jimingshi.us/?page_id=94
---
<table style="width: 588px; height: 235px;" cellspacing="0" cellpadding="0">
  <colgroup> <col width="310" /> <col width="251" /> <col width="63" /> </colgroup> <tr style="height: 56px;" valign="BOTTOM">
    <td style="width: 241px; height: 56px;">
      <p class="western">
        <span style="font-family: georgia,palatino,serif; font-size: medium;">Department of Astrophysical Sciences</span>
      </p>
    </td>
    
    <td style="width: 339px; height: 56px;" colspan="2">
      <p class="western" align="RIGHT">
        <span style="font-family: georgia,palatino,serif; font-size: medium;">jmshi@astro.princeton.edu</span>
      </p>
    </td>
  </tr>
  
  <tr style="height: 56px;" valign="BOTTOM">
    <td style="width: 241px; height: 56px;">
      <p class="western">
        <span style="font-family: georgia,palatino,serif; font-size: medium;">4 Ivy Lane</span>
      </p>
    </td>
    
    <td style="width: 339px; height: 56px;" colspan="2">
      <p class="western" align="RIGHT">
        <span style="font-family: georgia,palatino,serif;"><sub><span style="color: #000080;"><span lang="zxx"><u><a href="http://jimingshi.us/"><span style="color: #0000ff;"><span style="font-size: medium;">http://jimingshi.us/</span></span></a></u></span></span></sub><u></u><u></u><u></u></span>
      </p>
    </td>
  </tr>
  
  <tr style="height: 56px;" valign="BOTTOM">
    <td style="width: 241px; height: 56px;">
      <p class="western">
        <span style="font-family: georgia,palatino,serif; font-size: medium;">Princeton University</span>
      </p>
    </td>
    
    <td style="width: 154.75px; height: 56px;">
      <p class="western" align="RIGHT">
        <span style="font-family: georgia,palatino,serif; font-size: medium;"><br /> </span>
      </p>
    </td>
    
    <td style="width: 184.25px; height: 56px;">
      <span style="font-family: georgia,palatino,serif; font-size: medium;">Office: (609)258-7375</span>
    </td>
  </tr>
  
  <tr style="height: 6.28334px;" valign="BOTTOM">
    <td style="width: 241px; height: 6.28334px;">
      <p class="western">
        <span style="font-family: georgia,palatino,serif; font-size: medium;">Princeton, NJ 08544</span>
      </p>
    </td>
    
    <td style="width: 154.75px; height: 6.28334px;">
      <span style="font-family: georgia,palatino,serif;"> </span>
    </td>
    
    <td style="width: 184.25px; height: 6.28334px;">
      <p class="western" align="RIGHT">
        <span style="font-family: georgia,palatino,serif; font-size: medium;">Fax: (609) 258-8226</span>
      </p>
    </td>
  </tr>
</table>

<p class="western">
  <span style="color: #000000; font-family: georgia,palatino,serif; font-size: large;"><b>SPECIALTIES AND INTERESTS</b></span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">High Performance Computation, Gas Dynamics, Accretion Disks, Planet/Planetesimal Formation,</span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">Magnetohydrodynamics(MHD), Turbulence, Active Galactic Nuclei (AGN) </span>
</p>

<table width="624" cellspacing="0" cellpadding="0">
  <colgroup> <col width="572" /> <col width="52" /> </colgroup> <tr valign="BOTTOM">
    <td style="width: 566.333px;" height="21">
      <p class="western">
        <span style="color: #000000; font-family: georgia,palatino,serif; font-size: large;"><b>EDUCATION</b></span>
      </p>
    </td>
    
    <td style="width: 51.6667px;">
      <span style="font-family: georgia,palatino,serif;"> </span>
    </td>
  </tr>
  
  <tr valign="BOTTOM">
    <td style="width: 566.333px;" height="32">
      <p class="western">
        <span style="font-family: georgia,palatino,serif; font-size: medium;"><b>Johns Hopkins University, Baltimore, MD</b></span>
      </p>
    </td>
    
    <td style="width: 51.6667px;">
      <span style="font-family: georgia,palatino,serif;"> </span>
    </td>
  </tr>
  
  <tr valign="BOTTOM">
    <td style="width: 566.333px;" height="19">
      <p class="western">
        <span style="font-family: georgia,palatino,serif; font-size: medium;">Ph.D. in Astronomy</span>
      </p>
    </td>
    
    <td style="width: 51.6667px;">
      <p class="western" align="RIGHT">
        <span style="font-family: georgia,palatino,serif; font-size: medium;">2011</span>
      </p>
    </td>
  </tr>
  
  <tr valign="BOTTOM">
    <td style="width: 566.333px;" height="19">
      <p class="western">
        <span style="font-family: georgia,palatino,serif; font-size: medium;">Advisor: Julian H. Krolik</span>
      </p>
    </td>
    
    <td style="width: 51.6667px;">
      <span style="font-family: georgia,palatino,serif;"> </span>
    </td>
  </tr>
  
  <tr valign="BOTTOM">
    <td style="width: 566.333px;" height="33">
      <p class="western">
        <span style="font-family: georgia,palatino,serif; font-size: medium;"><b>University of Science and Technology of China (USTC), Hefei, China</b></span>
      </p>
    </td>
    
    <td style="width: 51.6667px;">
      <span style="font-family: georgia,palatino,serif;"> </span>
    </td>
  </tr>
  
  <tr valign="BOTTOM">
    <td style="width: 566.333px;" height="19">
      <p class="western">
        <span style="font-family: georgia,palatino,serif; font-size: medium;">M.S. in Astronomy</span>
      </p>
    </td>
    
    <td style="width: 51.6667px;">
      <p class="western" align="RIGHT">
        <span style="font-family: georgia,palatino,serif; font-size: medium;">2005</span>
      </p>
    </td>
  </tr>
  
  <tr valign="BOTTOM">
    <td style="width: 566.333px;" height="19">
      <p class="western">
        <span style="font-family: georgia,palatino,serif; font-size: medium;">B.S. in Astronomy</span>
      </p>
    </td>
    
    <td style="width: 51.6667px;">
      <p class="western" align="RIGHT">
        <span style="font-family: georgia,palatino,serif; font-size: medium;">2002</span>
      </p>
    </td>
  </tr>
</table>

<p class="western">
  <span style="font-family: georgia,palatino,serif; font-size: large;"><b>PROFESSIONAL EXPERIENCE</b></span>
</p>

<span style="font-size: 12pt; font-family: georgia,palatino,serif;">Associate research scholar, Max-Planck-Princeton Center for Fusion and Astro Plasma Physics (MPPC), Department of Astrophysical Sciences,  Princeton University    2017 &#8211; present</span>

<p class="western">
  <span style="font-family: georgia,palatino,serif;"><span style="font-size: medium;">Postdoctoral Research Associate, MPPC, Department of Astrophysical Sciences,  Princeton University</span>    <span style="font-size: medium;">2014 &#8211; 2017<br /> </span></span>
</p>

<p class="western">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">CIPS/TAC Postdoctoral Fellow, University of California, Berkeley  2011- 2014<br /> </span>
</p>

<span style="font-family: georgia,palatino,serif; font-size: medium;">Research Assistant, Johns Hopkins University  2005 &#8211; 2011</span>
:   
:   

<p class="western">
  <span style="font-family: georgia,palatino,serif; font-size: large;"><b>COMPUTATIONAL EXPERIENCE</b></span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif;"><span style="font-size: medium;">Extensive experience in </span><span style="font-size: medium;"><b>High Performance Computing (HPC)</b></span><span style="font-size: medium;"> on large scale computing systems in </span><span style="font-size: medium;"><b>TeraGrid / XSEDE</b></span><span style="font-size: medium;"> network</span><span style="font-size: medium;">.<br /> </span></span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">Extensive experience in development of MPI-based parallel computing programs (such as ZEUS3D variants, Athena and Athena++) for both local and global MHD simulations of accretion disks.</span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">Extensive knowledge of large scale data analysis and visualization using tools such as Python, IDL and VisIt.</span>
</p>

<p class="western">
  <span style="font-family: georgia,palatino,serif; font-size: large;"><b>REFEREED PUBLICATIONS</b></span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">Publication list on  <a href="http://adsabs.harvard.edu/cgi-bin/nph-abs_connect?cookie=4a70c1466922129">ADS</a>, <a href="https://scholar.google.com/citations?user=uVvbM9cAAAAJ&hl=en">Google Scholar</a> and<a href="http://arxiv.org:443/find/astro-ph/1/OR+au:+Shi_Ji_Ming+au:+Shi_Jiming/0/1/0/all/0/1"> arXiv</a></span>
</p>

<p class="western">
  <span style="font-family: georgia,palatino,serif; font-size: large;"><b>RECENT/UPCOMING TALKS<br /> </b></span>
</p>

<p align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: 12pt;">Numerical Simulations of Planet-Disc Interactions Workshop, Cuernavaca, Mexico, 2017</span>
</p>

<p align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: 12pt;">Max-Planck Princeton Center workshop, Greifswald, Germany, 2017</span>
</p>

<p align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: 12pt;">Yokohama Institute for Earth Sciences seminar, JAMSTEC, Yokohama, 2017</span>
</p>

<p align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: 12pt;">Kavli migration workshop, Cambridge University, 2017</span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: 12pt;">The Dynamo workshop, PCTS, Princeton University, 2015</span>
</p>

&nbsp;

<p class="western">
  <span style="font-family: georgia,palatino,serif; font-size: large;"><b>PROFESSIONAL SERVICE</b></span>
</p>

<p class="western">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">Member of American Astronomy Society (AAS) &  American Physical Society (APS) </span>
</p>

<p class="western">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">Referee for <em>Science</em>, <em>The Astrophysical Journal (ApJ)</em>  & <em>Astrophysical Journal Letters (ApJL)</em></span>
</p>

<p class="western">
  <span style="font-family: georgia,palatino,serif; font-size: large;"><b>HONORS</b></span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">CIPS Fellowship, UC Berkeley, 2011-2014</span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">Full Tuition Fellowship, Johns Hopkins University, 2005-2011</span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">Swomley and Kerr Fellowship, Johns Hopkins University, 2005</span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">Excellent Graduate of University of Science and Technology of China, 2002 </span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">Outstanding Student Scholarship, 1998-2001</span>
</p>

<p class="western">
  <span style="font-family: georgia,palatino,serif; font-size: large;"><b>TEACHING EXPERIENCE<br /> </b></span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">Mentor for Undergraduate Summer Research Program (USRP), Princeton, 2015-2017 </span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">Teaching Assistant for Beginning Chinese, JHU, Spring and Fall 2007</span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">Instructor for General Physics Lab, JHU, Fall 2005 and Spring 2006</span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">Teaching Assistant for General Physics, JHU, Fall 2005 and Spring 2006</span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">Teaching Assistant for Electromagnetism and Mechanics, USTC, Spring 2003</span>
</p>

<p class="western" align="JUSTIFY">
  <span style="font-family: georgia,palatino,serif; font-size: medium;">Teaching Assistant for Thermodynamics and Electromagnetism, USTC, Fall 2002</span>
</p>